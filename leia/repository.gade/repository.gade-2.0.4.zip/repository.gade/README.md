## Gade's Add-on Repository

This repository add-on allows you to get automatic updates and follow development of the Rapier skin and other add-ons for Kodi (https://github.com/gade01/Rapier).

### How to install this repository:

- [Get the latest release for Kodi 17 Krypton](https://github.com/gade01/repository.gade/raw/master/krypton/repository.gade/repository.gade-2.0.4.zip)
- [Get the latest release for Kodi 18 Leia](https://github.com/gade01/repository.gade/raw/master/leia/repository.gade/repository.gade-2.0.4.zip)
- [How to install in XBMC/Kodi](http://kodi.wiki/index.php?title=HOW-TO:Install_an_Add-on_from_a_zip_file)

license: http://creativecommons.org/licenses/by-nc-sa/3.0/
