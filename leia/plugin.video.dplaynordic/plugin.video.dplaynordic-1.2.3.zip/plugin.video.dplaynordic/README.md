# plugin.video.dplaynordic
Dplay addon for Kodi

# Disclaimer
This addon is unofficial and it is not supported by Discovery Networks, so it can break at anytime.

# Supported platforms
- Linux
- Mac
- Windows (not tested)
- Android (not tested)

# Supported countries
- Finland
- Sweden
- Denmark
- Norway
- Netherlands

# Features
- Supports <a href="https://forum.kodi.tv/showthread.php?tid=336747">Up Next</a>
- Playback progress is same in Dplay site and on Kodi addon (you can start video on site and continue it on Kodi or other way round)
- Live TV channels
- Videos
