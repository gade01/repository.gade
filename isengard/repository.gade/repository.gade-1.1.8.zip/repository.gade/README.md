## Gade's Add-on Repository

This repository add-on allows you to get automatic updates and follow development of the Rapier skin and other add-ons for Kodi (https://github.com/gade01/Rapier).

### How to install this repository:

- [Get the latest release for XBMC 13 Gotham](https://github.com/gade01/repository.gade/raw/master/gotham/repository.gade/repository.gade-1.1.8.zip)
- [Get the latest release for Kodi 14 Helix](https://github.com/gade01/repository.gade/raw/master/helix/repository.gade/repository.gade-1.1.8.zip)
- [Get the latest release for Kodi 15 Isengard](https://github.com/gade01/repository.gade/raw/master/isengard/repository.gade/repository.gade-1.1.8.zip)
- [Get the latest release for Kodi 16 Jarvis](https://github.com/gade01/repository.gade/raw/master/jarvis/repository.gade/repository.gade-1.1.8.zip)
- [How to install in XBMC/Kodi](http://kodi.wiki/index.php?title=HOW-TO:Install_an_Add-on_from_a_zip_file)

license: http://creativecommons.org/licenses/by-nc-sa/3.0/
