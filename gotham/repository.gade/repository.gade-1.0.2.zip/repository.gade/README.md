===============
repository.gade
===============

This repository add-on allows you to get automatic updates and follow development of the Rapier skin for XBMC/Kodi (https://github.com/gade01/Rapier).

How to install this repository:

- Get the latest release: https://github.com/gade01/repository.gade/blob/master/repository.gade-1.0.1.zip?raw=true
- Install in XBMC/Kodi: http://kodi.wiki/index.php?title=HOW-TO:Install_an_Add-on_from_a_zip_file

license: http://creativecommons.org/licenses/by-nc-sa/3.0/